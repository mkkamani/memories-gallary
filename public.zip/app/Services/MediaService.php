<?php

namespace App\Services;

use App\Models\Album;
use App\Models\Media;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use App\Interfaces\StorageServiceInterface;
use App\Support\MediaDimensionExtractor;

class MediaService
{
    protected $storageService;
    protected ThumbnailService $thumbnailService;

    public function __construct(StorageServiceInterface $storageService, ThumbnailService $thumbnailService)
    {
        $this->storageService   = $storageService;
        $this->thumbnailService = $thumbnailService;
    }

    public function upload(UploadedFile $file, User $user, ?Album $album = null)
    {
        $albumPath = $this->getAlbumUploadPath($album);
        $mimeType  = (string) ($file->getMimeType() ?: 'application/octet-stream');
        $fileType  = str_starts_with($mimeType, 'video') ? 'video' : 'image';

        $path = $this->storageService->uploadFile($file, $albumPath);
        [$width, $height] = MediaDimensionExtractor::fromUploadedFile($file, $mimeType);

        $media = Media::create([
            'user_id'   => $user->id,
            'album_id'  => $album?->id,
            'file_path' => $path,
            'file_name' => $file->getClientOriginalName(),
            'file_type' => $fileType,
            'file_size' => $file->getSize(),
            'mime_type' => $mimeType,
            'width'     => $width,
            'height'    => $height,
            'taken_at'  => now(),
        ]);

        // Generate thumbnail; errors are logged but never bubble up.
        try {
            $status = $this->thumbnailService->generateWithStatus($media);

            if ($status === 'generated' && $this->shouldSyncDimensionsFromThumbnail($media)) {
                $this->thumbnailService->syncDimensionsFromThumbnail($media);
            }
        } catch (\Throwable $e) {
            Log::warning('MediaService: thumbnail generation failed after upload.', [
                'media_id' => $media->id,
                'error'    => $e->getMessage(),
            ]);
        }

        return $media;
    }

    public function getAlbumUploadPath(?Album $album): string
    {
        if ($album && $album->r2_path) {
            return $album->r2_path;
        }

        if ($album) {
            // Fallback for albums that were created before r2_path was introduced.
            $locationSlug = Str::slug((string) ($album->location ?: 'Rajkot'));
            if ($locationSlug === '') {
                $locationSlug = 'rajkot';
            }

            return "albums/{$locationSlug}/" . str_replace(" ", "_", strtolower($album->title)) . "_" . $album->id;
        }

        return "uploads";
    }

    public function uploadFileOnly(UploadedFile $file, ?Album $album = null): string
    {
        $albumPath = $this->getAlbumUploadPath($album);
        return $this->storageService->uploadFile($file, $albumPath);
    }

    /**
     * Soft-delete a live media record, or permanently purge it when it is
     * already in the trash.
     *
     * - Live record  → soft-delete only (file stays in R2 so it can be restored).
     * - Trashed record → delegates to purge() which removes the R2 file and
     *   hard-deletes the DB row in one step.
     */
    public function delete(Media $media): bool
    {
        if ($media->trashed()) {
            return $this->purge($media);
        }

        return (bool) $media->delete();
    }

    /**
     * Unconditionally and permanently remove a media item:
     *   1. Delete the underlying file from the R2 bucket.
     *   2. Hard-delete (forceDelete) the database record.
     *
     * This method is the single authoritative entry-point for permanent removal.
     * It is safe to call on both live and already-trashed records because it
     * bypasses the soft-delete check entirely.
     *
     * Use cases:
     *   - Admin "Permanently Delete" action from the Recycle Bin.
     *   - Cascading delete when a parent album is force-deleted.
     *   - Scheduled purge of items that have been in the trash for > 7 days.
     */
    public function purge(Media $media): bool
    {
        try {
            $this->thumbnailService->delete($media);
        } catch (\Throwable $e) {
            Log::warning('MediaService::purge – could not delete thumbnail; proceeding with media purge.', [
                'media_id' => $media->id,
                'thumbnail_path' => $media->thumbnail_path,
                'error' => $e->getMessage(),
            ]);
        }

        try {
            $this->storageService->deleteFile($media->file_path);
        } catch (\Throwable $e) {
            // Log the R2 error but still remove the DB record so orphaned rows
            // do not accumulate. The file may have already been deleted manually
            // or may never have existed (e.g. failed upload that was rolled back).
            Log::warning('MediaService::purge – could not delete R2 file; proceeding with DB delete.', [
                'media_id'  => $media->id,
                'file_path' => $media->file_path,
                'error'     => $e->getMessage(),
            ]);
        }

        return (bool) $media->forceDelete();
    }

    private function shouldSyncDimensionsFromThumbnail(Media $media): bool
    {
        if (empty($media->thumbnail_path)) {
            return false;
        }

        $width = (int) ($media->width ?? 0);
        $height = (int) ($media->height ?? 0);

        if ($width <= 0 || $height <= 0) {
            return true;
        }

        return false;
    }
}
